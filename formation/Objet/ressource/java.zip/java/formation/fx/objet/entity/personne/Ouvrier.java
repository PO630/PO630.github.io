package formation.fx.objet.entity.personne;

import java.util.ArrayList;
import java.util.List;

import formation.fx.objet.entity.Outil;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Ouvrier")
public class Ouvrier extends Personne {

    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Manager manager;
    
    @OneToMany(mappedBy = "ouvrier", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Outil> outils = new ArrayList<>();

    // Constructeurs, getters et setters

    public Ouvrier() {
        super();
    }

    public Ouvrier(String nom, String prenom, String mail, Manager manager) {
        super(nom, prenom, mail);
        this.manager = manager;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
    
    public List<Outil> getOutils() {
        return outils;
    }

    public void setOutils(List<Outil> outils) {
        this.outils = outils;
    }

    public void addOutil(Outil outil) {
        outils.add(outil);
        outil.setOuvrier(this); // Établir la relation inverse
    }

    public void removeOutil(Outil outil) {
        outils.remove(outil);
        outil.setOuvrier(null); // Établir la relation inverse
    }
    
    @Override
    public RolePersonne getRole() {
        return RolePersonne.OUVRIER; // Retourne le rôle Ouvrier
    }
    
    /**
     * Retourne une couleur pour la cellule ID.
     *
     * @return String contenant le style de couleur pour la cellule ID.
     */
    @Override
    public String idTableColor() {
        return "style='background-color: red; color: white;'";
    }
}

package formation.fx.objet.controller.rest;

import formation.fx.objet.entity.personne.Ouvrier;
import formation.fx.objet.service.OuvrierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/ouvriers")
public class OuvrierController {

    private final OuvrierService ouvrierService;

    @Autowired
    public OuvrierController(OuvrierService ouvrierService) {
        this.ouvrierService = ouvrierService;
    }

    @GetMapping
    public List<Ouvrier> getAllOuvriers() {
        return ouvrierService.getAllOuvriers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ouvrier> getManagerById(@PathVariable int id) {
        Optional<Ouvrier> ouvrier = Optional.of(ouvrierService.getOuvrierById(id));
        return ouvrier.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/email/{mail}")
    public ResponseEntity<Ouvrier> getManagerByEmail(@PathVariable String mail) {
        Optional<Ouvrier> ouvrier = Optional.of(ouvrierService.findByMail(mail));
        return ouvrier.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }
}

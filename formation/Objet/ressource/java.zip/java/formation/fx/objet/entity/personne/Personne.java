package formation.fx.objet.entity.personne;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class Personne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false)
    private String prenom;

    @Column(nullable = false, unique = true)
    private String mail;

    // Constructeurs, getters et setters

    public Personne() {}

    public Personne(String nom, String prenom, String mail) {
        this.nom = nom;
        this.prenom = prenom;
        this.mail = mail;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
    
    /**
     * Retourne le rôle de la personne.
     * @return Le rôle, ou null si non défini.
     */
    public RolePersonne getRole() 
    {
        return null; // Par défaut, aucune personne n'a de rôle défini
    }
    
    /**
     * Retourne l'en-tête du tableau HTML.
     *
     * @return String contenant l'en-tête du tableau.
     */
    public static String toHeaderTable() {
        return "<tr>" +
                "<th>ID</th>" +
                "<th>Nom</th>" +
                "<th>Prénom</th>" +
                "<th>Email</th>" +
                "</tr>";
    }

    /**
     * Retourne une ligne du tableau HTML représentant les informations de la personne.
     *
     * @return String contenant une ligne du tableau.
     */
    public String toLigneTable() {
        return "<tr>" +
        		"<td " + idTableColor() + ">" + id + "</td>" +
                "<td>" + nom + "</td>" +
                "<td>" + prenom + "</td>" +
                "<td>" + mail + "</td>" +
                "</tr>";
    }
    
    /**
     * Retourne une couleur pour la cellule ID.
     *
     * @return String contenant le style de couleur pour la cellule ID.
     */
    public String idTableColor() {
        return "style='background-color: black; color: white;'";
    }
    
}

package formation.fx.objet.entity.personne;

import java.util.ArrayList;
import java.util.List;

import formation.fx.objet.entity.Qualification;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Artisan")
public class Artisan extends Personne {

    @ManyToOne
    @JoinColumn(name = "manager_id", nullable = false)
    private Manager manager;
    
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
        name = "Qualifier",
        joinColumns = @JoinColumn(name = "id_artisan"),
        inverseJoinColumns = @JoinColumn(name = "id_qualification")
    )
    private List<Qualification> qualifications = new ArrayList<>();

    // Constructeurs, getters et setters

    public Artisan() {
        super();
    }

    public Artisan(String nom, String prenom, String mail, Manager manager) {
        super(nom, prenom, mail);
        this.manager = manager;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
    
    public List<Qualification> getQualifications() {
        return qualifications;
    }

    public void setQualifications(List<Qualification> qualifications) {
        this.qualifications = qualifications;
    }

    public void addQualification(Qualification qualification) {
        qualifications.add(qualification);
    }

    public void removeQualification(Qualification qualification) {
        qualifications.remove(qualification);
    }
    
    @Override
    public RolePersonne getRole() {
        return RolePersonne.ARTISAN; // Retourne le rôle Artisan
    }
    
    /**
     * Retourne une couleur pour la cellule ID.
     *
     * @return String contenant le style de couleur pour la cellule ID.
     */
    @Override
    public String idTableColor() {
        return "style='background-color: green; color: white;'";
    }
}

package formation.fx.objet.service;

import java.util.List;
import java.util.Optional;

import formation.fx.objet.entity.Entreprise;

/**
 * Service pour gérer les opérations liées aux entreprises.
 */
public interface EntrepriseService {

    /**
     * Récupère toutes les entreprises.
     *
     * @return la liste de toutes les entreprises
     */
    List<Entreprise> getAllEntreprises();

    /**
     * Trouve une entreprise par son identifiant.
     *
     * @param id l'identifiant de l'entreprise à rechercher
     * @return un {@link Optional} contenant l'entreprise si trouvée, sinon vide
     */
    Optional<Entreprise> getEntrepriseById(Long id);

    /**
     * Sauvegarde une nouvelle entreprise ou met à jour une entreprise existante.
     *
     * @param entreprise l'entreprise à sauvegarder
     * @return l'entreprise sauvegardée
     */
    Entreprise saveEntreprise(Entreprise entreprise);

    /**
     * Supprime une entreprise par son identifiant.
     *
     * @param id l'identifiant de l'entreprise à supprimer
     */
    void deleteEntreprise(Long id);
    
}
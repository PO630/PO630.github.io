package formation.fx.objet.controller.rest;

import formation.fx.objet.entity.personne.Artisan;
import formation.fx.objet.service.ArtisanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/artisans")
public class ArtisanController {

    private final ArtisanService artisanService;

    @Autowired
    public ArtisanController(ArtisanService artisanService) {
        this.artisanService = artisanService;
    }

    @GetMapping
    public List<Artisan> getAllArtisans() {
        return artisanService.getAllArtisans();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Artisan> getManagerById(@PathVariable int id) {
        Optional<Artisan> artisan = Optional.of(artisanService.getArtisanById(id));
        return artisan.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/email/{mail}")
    public ResponseEntity<Artisan> getManagerByEmail(@PathVariable String mail) {
        Optional<Artisan> artisan = Optional.of(artisanService.findByMail(mail));
        return artisan.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }
}

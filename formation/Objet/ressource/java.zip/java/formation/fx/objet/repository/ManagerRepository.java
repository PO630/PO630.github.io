package formation.fx.objet.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import formation.fx.objet.entity.personne.Manager;

@Repository
public interface ManagerRepository extends CrudRepository<Manager, Long> 
{
	Manager findById( int id ) ;
	
	Manager findByMail(String mail);
}

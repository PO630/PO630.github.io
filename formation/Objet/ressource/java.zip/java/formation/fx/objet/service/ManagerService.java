package formation.fx.objet.service;


import java.util.List;

import formation.fx.objet.entity.personne.Manager;

/**
 * Interface de service pour gérer les opérations liées aux Managers.
 */
public interface ManagerService {
    
    /**
     * Récupère la liste de tous les managers.
     *
     * @return une liste de tous les managers.
     */
    List<Manager> getAllManagers();

    /**
     * Récupère un manager par son ID.
     *
     * @param id l'identifiant du manager à récupérer.
     * @return le manager si trouvé, sinon vide.
     */
    Manager getManagerById(int id);

    /**
     * Enregistre un nouveau manager.
     *
     * @param manager le manager à enregistrer.
     * @return le manager enregistré.
     */
    Manager saveManager(Manager manager);

    /**
     * Supprime un manager par son ID.
     *
     * @param id l'identifiant du manager à supprimer.
     */
    void deleteManager(Long id);
    
    /**
     * Recherche un manager par son email.
     * @param mail L'email du manager.
     * @return le manager si trouvé.
     */
    Manager findByMail(String mail);
}

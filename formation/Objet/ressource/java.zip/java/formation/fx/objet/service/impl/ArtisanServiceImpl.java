package formation.fx.objet.service.impl;

import formation.fx.objet.entity.personne.Artisan;
import formation.fx.objet.repository.ArtisanRepository;
import formation.fx.objet.service.ArtisanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Implémentation du service pour gérer les opérations liées aux Artisans.
 */
@Service
public class ArtisanServiceImpl implements ArtisanService {

    private final ArtisanRepository artisanRepository;
    private static final Logger logger = LoggerFactory.getLogger(ArtisanServiceImpl.class);

    @Autowired
    public ArtisanServiceImpl(ArtisanRepository artisanRepository) {
        this.artisanRepository = artisanRepository;
    }

    @Override
    public List<Artisan> getAllArtisans() {
        try {
            logger.info("Récupération de la liste de tous les artisans");
            return (List<Artisan>) artisanRepository.findAll();
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des artisans", e);
            throw e;
        }
    }

    @Override
    public Artisan getArtisanById(int id) {
        try {
            logger.info("Récupération de l'artisan avec l'ID: {}", id);
            return artisanRepository.findById(id);
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération de l'artisan avec l'ID: {}", id, e);
            throw e;
        }
    }

    @Override
    public Artisan saveArtisan(Artisan artisan) {
        try {
            logger.info("Sauvegarde de l'artisan: {}", artisan);
            return artisanRepository.save(artisan);
        } catch (Exception e) {
            logger.error("Erreur lors de la sauvegarde de l'artisan: {}", artisan, e);
            throw e;
        }
    }

    @Override
    public void deleteArtisan(Long id) {
        try {
            logger.info("Suppression de l'artisan avec l'ID: {}", id);
            artisanRepository.deleteById(id);
        } catch (Exception e) {
            logger.error("Erreur lors de la suppression de l'artisan avec l'ID: {}", id, e);
            throw e;
        }
    }
    
    @Override
    public Artisan findByMail(String mail) {
        try {
            return artisanRepository.findByMail(mail);
        } catch (Exception e) {
            logger.error("Erreur lors de la recherche de l'artisan par email: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la recherche de l'artisan par email", e);
        }
    }
}

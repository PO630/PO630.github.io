package formation.fx.objet.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import formation.fx.objet.entity.personne.Ouvrier;


@Repository
public interface OuvrierRepository extends CrudRepository<Ouvrier, Long> 
{
	Ouvrier findById( int id ) ;
	
	Ouvrier findByMail(String mail);
}

package formation.fx.objet.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import formation.fx.objet.entity.Entreprise;


/**
 * Repository pour gérer les entités {@link Entreprise}.
 * <p>
 * Cette interface étend {@link CrudRepository}, fournissant des méthodes pour
 * effectuer des opérations CRUD sur les entités {@link Entreprise}.
 * </p>
 */
@Repository
public interface EntrepriseRepository extends CrudRepository<Entreprise, Long> {

    /**
     * Trouve une entreprise par son identifiant.
     *
     * @param id l'identifiant de l'entreprise à rechercher
     * @return un {@link Optional} contenant l'entreprise si trouvée, sinon vide
     */
    Optional<Entreprise> findById(Long id);
    
    /**
     * Récupère toutes les entreprises.
     *
     * @return une liste de toutes les entreprises
     */
    List<Entreprise> findAll();
}

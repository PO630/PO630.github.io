package formation.fx.objet.service;

import formation.fx.objet.entity.personne.Artisan;

import java.util.List;

/**
 * Interface de service pour gérer les opérations liées aux Artisans.
 */
public interface ArtisanService {
    
    /**
     * Récupère la liste de tous les artisans.
     *
     * @return une liste de tous les artisans.
     */
    List<Artisan> getAllArtisans();

    /**
     * Récupère un artisan par son ID.
     *
     * @param id l'identifiant de l'artisan à récupérer.
     * @return l'artisan si trouvé, sinon vide.
     */
    Artisan getArtisanById(int id);

    /**
     * Enregistre un nouvel artisan.
     *
     * @param artisan l'artisan à enregistrer.
     * @return l'artisan enregistré.
     */
    Artisan saveArtisan(Artisan artisan);

    /**
     * Supprime un artisan par son ID.
     *
     * @param id l'identifiant de l'artisan à supprimer.
     */
    void deleteArtisan(Long id);
    
    /**
     * Recherche un artisan par son email.
     * @param mail L'email de l'artisan.
     * @return l'artisan si trouvé.
     */
    Artisan findByMail(String mail);
}

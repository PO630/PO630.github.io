package formation.fx.objet.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import formation.fx.objet.entity.Entreprise;
import formation.fx.objet.repository.EntrepriseRepository;
import formation.fx.objet.service.EntrepriseService;

/**
 * Implémentation du service {@link EntrepriseService}.
 */
@Service
public class EntrepriseServiceImpl implements EntrepriseService {

    private static final Logger logger = LoggerFactory.getLogger(EntrepriseServiceImpl.class);
    private final EntrepriseRepository entrepriseRepository;

    @Autowired
    public EntrepriseServiceImpl(EntrepriseRepository entrepriseRepository) {
        this.entrepriseRepository = entrepriseRepository;
    }

    @Override
    public List<Entreprise> getAllEntreprises() {
        logger.info("Récupération de la liste de toutes les entreprises.");
        try {
            List<Entreprise> entreprises = (List<Entreprise>) entrepriseRepository.findAll();
            logger.info("Nombre d'entreprises récupérées : {}", entreprises.size());
            return entreprises;
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des entreprises", e);
            throw e; // Re-throw ou gérer selon vos besoins
        }
    }

    @Override
    public Optional<Entreprise> getEntrepriseById(Long id) {
        logger.info("Recherche de l'entreprise avec l'identifiant : {}", id);
        try {
            Optional<Entreprise> entreprise = entrepriseRepository.findById(id);
            if (entreprise.isPresent()) {
                logger.info("Entreprise trouvée : {}", entreprise.get().getNom());
            } else {
                logger.warn("Aucune entreprise trouvée avec l'identifiant : {}", id);
            }
            return entreprise;
        } catch (Exception e) {
            logger.error("Erreur lors de la recherche de l'entreprise avec l'identifiant : {}", id, e);
            throw e; // Re-throw ou gérer selon vos besoins
        }
    }

    @Override
    public Entreprise saveEntreprise(Entreprise entreprise) {
        logger.info("Sauvegarde de l'entreprise : {}", entreprise.getNom());
        try {
            Entreprise savedEntreprise = entrepriseRepository.save(entreprise);
            logger.info("Entreprise sauvegardée avec succès : {}", savedEntreprise.getNom());
            return savedEntreprise;
        } catch (Exception e) {
            logger.error("Erreur lors de la sauvegarde de l'entreprise : {}", entreprise.getNom(), e);
            throw e; // Re-throw ou gérer selon vos besoins
        }
    }

    @Override
    public void deleteEntreprise(Long id) {
        logger.info("Suppression de l'entreprise avec l'identifiant : {}", id);
        try {
            entrepriseRepository.deleteById(id);
            logger.info("Entreprise supprimée avec succès : {}", id);
        } catch (Exception e) {
            logger.error("Erreur lors de la suppression de l'entreprise avec l'identifiant : {}", id, e);
            throw e; // Re-throw ou gérer selon vos besoins
        }
    }
}

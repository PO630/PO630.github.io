package formation.fx.objet.service.impl;

import formation.fx.objet.entity.personne.Manager;
import formation.fx.objet.repository.ManagerRepository;
import formation.fx.objet.service.ManagerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Implémentation du service pour gérer les opérations liées aux Managers.
 */
@Service
public class ManagerServiceImpl implements ManagerService {

    private final ManagerRepository managerRepository;
    private static final Logger logger = LoggerFactory.getLogger(ManagerServiceImpl.class);

    @Autowired
    public ManagerServiceImpl(ManagerRepository managerRepository) {
        this.managerRepository = managerRepository;
    }

    @Override
    public List<Manager> getAllManagers() {
        try {
            logger.info("Récupération de la liste de tous les managers");
            return (List<Manager>) managerRepository.findAll();
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des managers", e);
            throw e; // Re-throwing the exception for higher-level handling
        }
    }

    @Override
    public Manager getManagerById(int id) {
        try {
            logger.info("Récupération du manager avec l'ID: {}", id);
            return managerRepository.findById(id);
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération du manager avec l'ID: {}", id, e);
            throw e;
        }
    }

    @Override
    public Manager saveManager(Manager manager) {
        try {
            logger.info("Sauvegarde du manager: {}", manager);
            return managerRepository.save(manager);
        } catch (Exception e) {
            logger.error("Erreur lors de la sauvegarde du manager: {}", manager, e);
            throw e;
        }
    }

    @Override
    public void deleteManager(Long id) {
        try {
            logger.info("Suppression du manager avec l'ID: {}", id);
            managerRepository.deleteById(id);
        } catch (Exception e) {
            logger.error("Erreur lors de la suppression du manager avec l'ID: {}", id, e);
            throw e;
        }
    }
    
    @Override
    public Manager findByMail(String mail) {
        try {
            return managerRepository.findByMail(mail);
        } catch (Exception e) {
            logger.error("Erreur lors de la recherche du manager par email: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la recherche du manager par email", e);
        }
    }
}

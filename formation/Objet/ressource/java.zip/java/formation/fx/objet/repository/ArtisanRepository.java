package formation.fx.objet.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import formation.fx.objet.entity.personne.Artisan;

@Repository
public interface ArtisanRepository extends CrudRepository<Artisan, Long> 
{
	Artisan findById( int id ) ;
	
	Artisan findByMail(String mail);
}

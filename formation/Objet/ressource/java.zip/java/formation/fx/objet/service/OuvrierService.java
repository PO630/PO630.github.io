package formation.fx.objet.service;

import formation.fx.objet.entity.personne.Ouvrier;

import java.util.List;

/**
 * Interface de service pour gérer les opérations liées aux Ouvriers.
 */
public interface OuvrierService {
    
    /**
     * Récupère la liste de tous les ouvriers.
     *
     * @return une liste de tous les ouvriers.
     */
    List<Ouvrier> getAllOuvriers();

    /**
     * Récupère un ouvrier par son ID.
     *
     * @param id l'identifiant de l'ouvrier à récupérer.
     * @return un objet Optional contenant l'ouvrier si trouvé, sinon vide.
     */
    Ouvrier getOuvrierById(int id);

    /**
     * Enregistre un nouvel ouvrier.
     *
     * @param ouvrier l'ouvrier à enregistrer.
     * @return l'ouvrier enregistré.
     */
    Ouvrier saveOuvrier(Ouvrier ouvrier);

    /**
     * Supprime un ouvrier par son ID.
     *
     * @param id l'identifiant de l'ouvrier à supprimer.
     */
    void deleteOuvrier(Long id);
    
    /**
     * Recherche un ouvrier par son email.
     * @param mail L'email de l'ouvrier.
     * @return Une Optional contenant l'ouvrier si trouvé.
     */
    Ouvrier findByMail(String mail);
}

package formation.fx.objet.service;

import java.util.List;

import formation.fx.objet.entity.personne.Personne;

/**
 * Interface pour gérer les opérations sur les personnes (Manager, Artisan, Ouvrier).
 */
public interface PersonneService {

    /**
     * Récupère toutes les personnes.
     * @return Une liste de toutes les personnes.
     */
    List<Personne> getAllPersonnes();

    /**
     * Récupère une personne par son identifiant.
     * @param id L'identifiant de la personne.
     * @return la personne si trouvée.
     */
    Personne getPersonneById(int id);

    /**
     * Sauvegarde une personne.
     * @param personne La personne à sauvegarder.
     * @return La personne sauvegardée.
     */
    Personne savePersonne(Personne personne);

    /**
     * Recherche une personne par son email.
     * @param email L'email de la personne.
     * @return la personne si trouvée.
     */
    Personne findByMail(String mail);
}

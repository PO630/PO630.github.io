package formation.fx.objet.entity;

import formation.fx.objet.entity.personne.Artisan;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Qualifier")
public class Qualifier {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_artisan", nullable = false)
    private Artisan artisan;

    @ManyToOne
    @JoinColumn(name = "id_qualification", nullable = false)
    private Qualification qualification;

    // Constructeurs, getters et setters

    public Qualifier() {}

    public Qualifier(Artisan artisan, Qualification qualification) {
        this.artisan = artisan;
        this.qualification = qualification;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Artisan getArtisan() {
        return artisan;
    }

    public void setArtisan(Artisan artisan) {
        this.artisan = artisan;
    }

    public Qualification getQualification() {
        return qualification;
    }

    public void setQualification(Qualification qualification) {
        this.qualification = qualification;
    }
}

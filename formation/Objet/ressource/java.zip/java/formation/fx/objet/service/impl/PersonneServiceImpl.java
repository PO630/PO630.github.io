package formation.fx.objet.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import formation.fx.objet.entity.personne.Personne;
import formation.fx.objet.entity.personne.Manager;
import formation.fx.objet.entity.personne.Artisan;
import formation.fx.objet.entity.personne.Ouvrier;
import formation.fx.objet.service.ManagerService;
import formation.fx.objet.service.ArtisanService;
import formation.fx.objet.service.OuvrierService;
import formation.fx.objet.service.PersonneService;

import java.util.ArrayList;
import java.util.List;

/**
 * Implémentation du service PersonneService.
 */
@Service
public class PersonneServiceImpl implements PersonneService {

    private static final Logger logger = LoggerFactory.getLogger(PersonneServiceImpl.class);
    private final ManagerService managerService;
    private final ArtisanService artisanService;
    private final OuvrierService ouvrierService;

    @Autowired
    public PersonneServiceImpl(ManagerService managerService,
                               ArtisanService artisanService,
                               OuvrierService ouvrierService) {
        this.managerService = managerService;
        this.artisanService = artisanService;
        this.ouvrierService = ouvrierService;
    }

    @Override
    public List<Personne> getAllPersonnes() {
        try {
            List<Personne> personnes = new ArrayList<>();
            personnes.addAll(managerService.getAllManagers());
            personnes.addAll(artisanService.getAllArtisans());
            personnes.addAll(ouvrierService.getAllOuvriers());
            return personnes;
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des personnes: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la récupération des personnes", e);
        }
    }

    @Override
    public Personne getPersonneById(int id) {
        try {
            Personne personne = managerService.getManagerById(id);
            if (personne==null) {
                personne = artisanService.getArtisanById(id);
            }
            if (personne==null) {
                personne = ouvrierService.getOuvrierById(id);
            }
            return personne;
        } catch (Exception e) {
            logger.error("Erreur lors de la recherche de la personne par ID: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la recherche de la personne par ID", e);
        }
    }

    @Override
    public Personne savePersonne(Personne personne) {
        try {
            if (personne instanceof Manager) {
                return managerService.saveManager((Manager) personne);
            } else if (personne instanceof Artisan) {
                return artisanService.saveArtisan((Artisan) personne);
            } else if (personne instanceof Ouvrier) {
                return ouvrierService.saveOuvrier((Ouvrier) personne);
            } else {
                throw new IllegalArgumentException("Type de personne non reconnu");
            }
        } catch (Exception e) {
            logger.error("Erreur lors de la sauvegarde de la personne: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la sauvegarde de la personne", e);
        }
    }

    @Override
    public Personne findByMail(String mail) {
        try {
            Personne personne = managerService.findByMail(mail);
            if (personne==null) {
                personne = artisanService.findByMail(mail);
            }
            if (personne==null) {
                personne = ouvrierService.findByMail(mail);
            }
            return personne;
        } catch (Exception e) {
            logger.error("Erreur lors de la recherche de la personne par email: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la recherche de la personne par email", e);
        }
    }


}

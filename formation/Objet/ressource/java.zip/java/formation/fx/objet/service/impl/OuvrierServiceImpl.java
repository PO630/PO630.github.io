package formation.fx.objet.service.impl;

import formation.fx.objet.entity.personne.Ouvrier;
import formation.fx.objet.repository.OuvrierRepository;
import formation.fx.objet.service.OuvrierService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Implémentation du service pour gérer les opérations liées aux Ouvriers.
 */
@Service
public class OuvrierServiceImpl implements OuvrierService {

    private final OuvrierRepository ouvrierRepository;
    private static final Logger logger = LoggerFactory.getLogger(OuvrierServiceImpl.class);

    @Autowired
    public OuvrierServiceImpl(OuvrierRepository ouvrierRepository) {
        this.ouvrierRepository = ouvrierRepository;
    }

    @Override
    public List<Ouvrier> getAllOuvriers() {
        try {
            logger.info("Récupération de la liste de tous les ouvriers");
            return (List<Ouvrier>) ouvrierRepository.findAll();
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des ouvriers", e);
            throw e;
        }
    }

    @Override
    public Ouvrier getOuvrierById(int id) {
        try {
            logger.info("Récupération de l'ouvrier avec l'ID: {}", id);
            return ouvrierRepository.findById(id);
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération de l'ouvrier avec l'ID: {}", id, e);
            throw e;
        }
    }

    @Override
    public Ouvrier saveOuvrier(Ouvrier ouvrier) {
        try {
            logger.info("Sauvegarde de l'ouvrier: {}", ouvrier);
            return ouvrierRepository.save(ouvrier);
        } catch (Exception e) {
            logger.error("Erreur lors de la sauvegarde de l'ouvrier: {}", ouvrier, e);
            throw e;
        }
    }

    @Override
    public void deleteOuvrier(Long id) {
        try {
            logger.info("Suppression de l'ouvrier avec l'ID: {}", id);
            ouvrierRepository.deleteById(id);
        } catch (Exception e) {
            logger.error("Erreur lors de la suppression de l'ouvrier avec l'ID: {}", id, e);
            throw e;
        }
    }
    
    @Override
    public Ouvrier findByMail(String mail) {
        try {
            return ouvrierRepository.findByMail(mail);
        } catch (Exception e) {
            logger.error("Erreur lors de la recherche de l'ouvrier par email: {}", e.getMessage());
            throw new RuntimeException("Erreur lors de la recherche de l'ouvrier par email", e);
        }
    }
}

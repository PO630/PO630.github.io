package formation.fx.objet.entity.personne;

/**
 * Enumération représentant les différents rôles dans l'application.
 */
public enum RolePersonne 
{
    MANAGER("Manager"),
    ARTISAN("Artisan"),
    OUVRIER("Ouvrier");

    private final String displayName;

    RolePersonne(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
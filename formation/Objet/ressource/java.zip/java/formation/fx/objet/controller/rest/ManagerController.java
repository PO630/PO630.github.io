package formation.fx.objet.controller.rest;

import formation.fx.objet.entity.personne.Manager;
import formation.fx.objet.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/managers")
public class ManagerController {

    private final ManagerService managerService;

    @Autowired
    public ManagerController(ManagerService managerService) {
        this.managerService = managerService;
    }

    @GetMapping
    public List<Manager> getAllManagers() {
        return managerService.getAllManagers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Manager> getManagerById(@PathVariable int id) {
        Optional<Manager> manager = Optional.of(managerService.getManagerById(id));
        return manager.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/email/{mail}")
    public ResponseEntity<Manager> getManagerByEmail(@PathVariable String mail) {
        Optional<Manager> manager = Optional.of(managerService.findByMail(mail));
        return manager.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }
}

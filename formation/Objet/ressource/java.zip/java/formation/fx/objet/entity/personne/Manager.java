package formation.fx.objet.entity.personne;

import formation.fx.objet.entity.Entreprise;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Manager")
public class Manager extends Personne {

    @Column
    private String titre;

    @ManyToOne
    @JoinColumn(name = "id_entreprise", nullable = false, foreignKey = @ForeignKey(name = "fk_manager_entreprise"))
    private Entreprise entreprise;

    // Constructeurs, getters et setters

    public Manager() {
        super();
    }

    public Manager(String nom, String prenom, String mail, String titre, Entreprise entreprise) {
        super(nom, prenom, mail);
        this.titre = titre;
        this.entreprise = entreprise;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Entreprise getEntreprise() {
        return entreprise;
    }

    public void setEntreprise(Entreprise entreprise) {
        this.entreprise = entreprise;
    }
    
    @Override
    public RolePersonne getRole() {
        return RolePersonne.MANAGER; // Retourne le rôle Manager
    }
    
    /**
     * Retourne une couleur pour la cellule ID.
     *
     * @return String contenant le style de couleur pour la cellule ID.
     */
    @Override
    public String idTableColor() {
        return "style='background-color: cyan; color: white;'";
    }
}
